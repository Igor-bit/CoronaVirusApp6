package com.igorcordeiroszeremeta.coronavirusapp6;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class Teste2 extends AppCompatActivity {

    CheckBox doresEDesconfortos;
    CheckBox dorDeGarganta;
    CheckBox diarreia;
    Button botaoPaginaAnterior2;
    Button botaoTeste2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.teste2);

        botaoTeste2 = findViewById(R.id.botaoTeste2);
        doresEDesconfortos = findViewById(R.id.doresEDesconfortos);
        dorDeGarganta = findViewById(R.id.dorDeGarganta);
        diarreia = findViewById(R.id.diarreia);
        botaoPaginaAnterior2= findViewById(R.id.botaoPaginaAnterior2);

        botaoTeste2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                int resultadoDaSegundaPagina = 0;

                if (doresEDesconfortos.isChecked()) {
                    resultadoDaSegundaPagina += 5;
                }

                if (dorDeGarganta.isChecked()) {
                    resultadoDaSegundaPagina += 5;
                }

                if (diarreia.isChecked()) {
                    resultadoDaSegundaPagina += 5;
                }

                Intent intentEnviadora = new Intent(getApplicationContext(), Resultado.class);
                Bundle parametro = new Bundle();

                parametro.putInt("resultado2", resultadoDaSegundaPagina);
                intentEnviadora.putExtras(parametro);
                startActivity(intentEnviadora);

                Intent intent = new Intent(getApplicationContext(), Teste3.class);
                startActivity(intent);
            }
        });

        botaoPaginaAnterior2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Teste1.class);
                startActivity(intent);
            }
        });
    }
}