package com.igorcordeiroszeremeta.coronavirusapp6;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class Teste3 extends AppCompatActivity {

    CheckBox conjuntivite;
    CheckBox dorDeCabeca;
    CheckBox perdaDePaladarOuOlfato;
    CheckBox erupcaoCutanea;
    Button botaoPaginaAnterior3;
    Button botaoTeste3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.teste3);

        botaoTeste3 = findViewById(R.id.botaoTeste3);
        conjuntivite = findViewById(R.id.conjuntivite);
        dorDeCabeca = findViewById(R.id.dorDeCabeca);
        perdaDePaladarOuOlfato = findViewById(R.id.perdaDePaladarOuOlfato);
        erupcaoCutanea = findViewById(R.id.erupcaoCutanea);

        botaoPaginaAnterior3 = findViewById(R.id.botaoPaginaAnterior3);

        botaoTeste3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int resultadoDaTerceiraPagina = 0;

                if (conjuntivite.isChecked()) {
                    resultadoDaTerceiraPagina += 5;
                }

                if (dorDeCabeca.isChecked()) {
                    resultadoDaTerceiraPagina += 5;
                }

                if (perdaDePaladarOuOlfato.isChecked()) {
                    resultadoDaTerceiraPagina += 5;
                }

                if (erupcaoCutanea.isChecked()) {
                    resultadoDaTerceiraPagina += 5;
                }

                //    textoTesteResultado.setText(String.valueOf(resultadoDaPrimeiraPagina));

                Bundle parametro = new Bundle();

                parametro.putInt("resultado3", resultadoDaTerceiraPagina);
                Intent intent = new Intent(getApplicationContext(), Teste4.class);
                startActivity(intent);
            }
        });

        botaoPaginaAnterior3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Teste2.class);
                startActivity(intent);
            }
        });
    }
}