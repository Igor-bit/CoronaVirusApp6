package com.igorcordeiroszeremeta.coronavirusapp6;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Resultado extends AppCompatActivity {

    TextView textoDoResultadoFinal;
    Button tratamento;
    Button botaoPrevencao1;
    Button resetar;
    TextView pontuacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.resultado);

        textoDoResultadoFinal = findViewById(R.id.textoDoResultadoFinal);
        tratamento = findViewById(R.id.tratamento);
        botaoPrevencao1 = findViewById(R.id.botaoPrevencao1);
        pontuacao = findViewById(R.id.pontuacao);

        Intent intentRecebedora = getIntent();
        Bundle parametros = intentRecebedora.getExtras();
        if(parametros != null) {

        int resultado1 = parametros.getInt("resultado1");
        int resultado2 = parametros.getInt("resultado2");
        int resultado3 = parametros.getInt("resultado3");
        int resultado4 = parametros.getInt("resultado4");

            int resultadoDoTeste = resultado1 + resultado2 + resultado3 + resultado4;

            if (resultadoDoTeste >= 0 && resultadoDoTeste <= 3) {
                textoDoResultadoFinal.setText("Você apresenta os sintomas leves. \nPor favor, se cuide.");

            } else if (resultadoDoTeste >= 4 && resultadoDoTeste < 12) {
                textoDoResultadoFinal.setText("Você apresenta os sintomas medianos. Por favor, tome cuidado. Em caso de piora, por favor, procure urgentemente uma unidade de saúde.");

            } else if (resultadoDoTeste >= 12 && resultadoDoTeste <= 35) {
                textoDoResultadoFinal.setText("Você apresenta os sintomas graves. \nPor favor, vá para uma unidade de \nsaúde.");

            } else if (resultadoDoTeste > 35) {
                textoDoResultadoFinal.setText("Você apresenta sintomas gravíssimos. Por favor, procure o mais rápido \npossível uma unidade de saúde.");
            }

            pontuacao.setText(resultadoDoTeste);
        }

        //   textoDoResultadoFinal.setText(String.valueOf(resultado1));

        resetar = findViewById(R.id.resetar);
        resetar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            recreate();
            Intent intent = new Intent(getApplicationContext(), Teste1.class);
            startActivity(intent);

            CheckBox febre = findViewById(R.id.febre);
                if (febre.isChecked()) {
                    febre.setChecked(false);
                }

            CheckBox tosseSeca = findViewById(R.id.tosseSeca);
                if (tosseSeca.isChecked()) {
                    tosseSeca.setChecked(false);
                }

            CheckBox cansaco = findViewById(R.id.cansaco);
                if (cansaco.isChecked()) {
                    cansaco.setChecked(false);
                }

             CheckBox doresEDesconfortos = findViewById(R.id.doresEDesconfortos);
                if (doresEDesconfortos.isChecked()) {
                    doresEDesconfortos.setChecked(false);
                }

            CheckBox dorDeGarganta = findViewById(R.id.dorDeGarganta);
                if (dorDeGarganta.isChecked()) {
                    dorDeGarganta.setChecked(false);
                }

            CheckBox diarreia = findViewById(R.id.diarreia);
                if (diarreia.isChecked()) {
                    diarreia.setChecked(false);
                }

            CheckBox conjuntivite = findViewById(R.id.conjuntivite);
                if (conjuntivite.isChecked()) {
                    conjuntivite.setChecked(false);
                }

             CheckBox dorDeCabeca = findViewById(R.id.dorDeCabeca);
                if (dorDeCabeca.isChecked()) {
                    dorDeCabeca.setChecked(false);
                }

             CheckBox perdaDePaladarOuOlfato = findViewById(R.id.perdaDePaladarOuOlfato);
                if (perdaDePaladarOuOlfato.isChecked()) {
                    perdaDePaladarOuOlfato.setChecked(false);
                }

             CheckBox erupcaoCutanea = findViewById(R.id.erupcaoCutanea);
                if (erupcaoCutanea.isChecked()) {
                    erupcaoCutanea.setChecked(false);
                }

              CheckBox dificuldadesParaRespirar = findViewById(R.id.dificuldadesParaRespirar);
                if (dificuldadesParaRespirar.isChecked()) {
                    dificuldadesParaRespirar.setChecked(false);
                }

               CheckBox dorOuPressaoNoPeito = findViewById(R.id.dorOuPressaoNoPeito);
                if (dorOuPressaoNoPeito.isChecked()) {
                    dorOuPressaoNoPeito.setChecked(false);
                }

               CheckBox perdaDeFalaOuPerdaDeMovimento = findViewById(R.id.perdaDeFalaOuMovimento);
                if (perdaDeFalaOuPerdaDeMovimento.isChecked()) {
                    perdaDeFalaOuPerdaDeMovimento.setChecked(false);
                }

            textoDoResultadoFinal.setText("");
            }
        });

        botaoPrevencao1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Prevencao1.class);
                startActivity(intent);
            }
        });

        tratamento.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Tratamentos1.class);
                startActivity(intent);
            }
        });
    }
}